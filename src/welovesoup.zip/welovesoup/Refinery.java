package welovesoup;
import battlecode.common.*;

public class Refinery extends Building {
    public Refinery(RobotController r) {
        super(r);
    }
}
