package welovesoup;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class netGun extends Shooter {
    public netGun(RobotController r) { super(r);}

    @Override
    public void takeTurn() throws GameActionException {
        super.takeTurn();
    }
}
