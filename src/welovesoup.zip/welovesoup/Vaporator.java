package welovesoup;
import battlecode.common.*;

public class Vaporator extends Building {
    public Vaporator(RobotController r) {
        super(r);
    }
}
